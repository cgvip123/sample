package NewHotelFeature;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},tags= {"@HotelBooking, @Navigation"},glue= "stepDef")
public class runNewHotelTest
{

}
